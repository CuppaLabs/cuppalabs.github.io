import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<virtual-scroll [datalist] = "arrayList" [config]="config"></virtual-scroll>`,
})
export class AppComponent  { 
  
  
  arrayList:any[] = [];
  config = {
    w: 300,
    h: 300,
    itemHeight: 31,
    totalRows: 10000,
    items: this.arrayList
  }
   constructor() {
       // document.body.appendChild(this.config.container)
       for(var t=0;t<10000;t++){
         var tempObj = {"val":"","variable":"","name":"","city":"","country":"","Mobile":""};
         tempObj.val = ""+t;
            this.arrayList.push(tempObj);
       }
    }
  }
