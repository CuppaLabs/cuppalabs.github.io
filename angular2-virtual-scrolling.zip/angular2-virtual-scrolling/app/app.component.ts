import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}} </h1><virtual-scroll [datalist] = "arrayList" [config]="config"></virtual-scroll>`,
})
export class AppComponent  { 
  
  arrayList = [];
  config = {
    w: 300,
    h: 300,
    itemHeight: 31,
    totalRows: 10000,
    items: this.arrayList
  }
   constructor() {
       // document.body.appendChild(this.config.container)
       for(var t=0;t<10000;t++){
            this.arrayList.push(""+t);
       }
    }
    
  
  name = 'Angular'; }
