import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule }       from '@angular/common';

import { VirtualScroll }  from './virtual-scroll.component';
import {KeysPipe} from './keypipe'
import {styleDirective} from './style-directive'
import {columnWidth} from './style-directive'

@NgModule({
  imports:      [ CommonModule ],
  declarations: [VirtualScroll,KeysPipe, styleDirective,columnWidth],
  exports:      [ VirtualScroll ]
})
export class CuppaGrid { }
