import { Component, OnInit, OnChanges, ViewEncapsulation, Input, Output, EventEmitter, ElementRef, AfterViewInit } from '@angular/core';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'virtual-scroll',
  templateUrl: 'app/virtual-scroll.template.html',
  styleUrls: ['app/virtual-scroll.styles.css'],
})
export class VirtualScroll implements AfterViewInit{ 
    
    @Input() datalist: any;
    @Input() config: any;

    private width:any;
    private height:any;
    private itemHeight:any;
    private items:any;
    private totalRows:any;
    private screenItemsLen:any;
    private cachedItemsLen:any;
    private lastRepaintY: any;
    private maxBuffer:any;
    private lastScrolled:any;
    private contianer:any
    private rmNodeInterval:any;
    private totalHeight: any;
    private scroller:any;
    private dataArray:any[] = ["111","222","333","444"];
    private tempArray:any[];
    private scrollTop:any;

    constructor(private _elementRef : ElementRef, private sanitizer: DomSanitizer) {   
    }

    ngOnInit() {
        console.log(this._elementRef);
        this.width = (this.config && this.config.w + 'px') || '100%';
        this.height = (this.config && this.config.h + 'px') || '100%';
        this.itemHeight = this.config.itemHeight;
        this.items = this.config.items;
        this.totalRows = this.config.totalRows || (this.config.items && this.config.items.length);
        this.screenItemsLen = Math.ceil(this.config.h / this.itemHeight);
        this.cachedItemsLen = this.screenItemsLen * 3;
        this.totalHeight = this.itemHeight * this.totalRows;
        this.scroller = this.createScroller(this.totalHeight);
        this.maxBuffer = this.screenItemsLen * this.itemHeight;
        this.lastScrolled = 0;
        console.log(this.items);
        this._renderChunk(0, this.cachedItemsLen / 2);
    }
    ngAfterViewInit() {
        console.log(this._elementRef.nativeElement.getElementsByClassName("container")[0]);       
        this._elementRef.nativeElement.getElementsByClassName("container")[0].addEventListener('scroll', this.onScroll.bind(this));
    }
    private changeData(){
        var temArr = ["1","2","3","4"];
         this.dataArray = temArr;
       /* for(var t=0;t< this.dataArray.length;t++){
            this.dataArray[t] = temArr[t];
        }*/
    }
    private getHeightVal(i:any){
        var c:any = i*31;
        c = c+"px";
        return c;
    }
    private onScroll(e:any) {
        this.scrollTop = e.target.scrollTop;
        this.updateView(this.scrollTop);

    }
    private updateView(scrollTop:any){
        var scrollPos = scrollTop ? scrollTop: 0;
         var first = (scrollPos / this.itemHeight) - this.screenItemsLen;
        var firstTemp = ""+first;
        first = parseInt(firstTemp) < 0 ? 0 : parseInt(firstTemp);
        //if (!this.lastRepaintY || Math.abs(scrollPos - this.lastRepaintY) > this.maxBuffer) {
            this._renderChunk(first, this.cachedItemsLen);
            this.lastRepaintY = scrollPos;
       // }
        
    }
    
    /*
        Create Row DOM, iterating through the data array
    */

    /*private _renderChunk(node:any, fromPos:any, howMany:any) {
        var fragment = document.createDocumentFragment();
        fragment.appendChild(this.scroller);
        var finalItem = fromPos + howMany;
        if (finalItem > this.totalRows)
            finalItem = this.totalRows;

        for (var i = fromPos; i < finalItem; i++) {
            var item:any;
            if (typeof this.items[i] === 'string') {
                var itemText = document.createTextNode(this.items[i]);
                item = document.createElement('div');
                //item.style.height = this.height;
                item.appendChild(itemText);
            } else {
                item = this.items[i];
            }

            item.classList.add('vrow');
            item.style.position = 'absolute';
            item.style.top = (i * this.itemHeight) + 'px';
            fragment.appendChild(item);
        }
        node.innerHTML = '';
        node.appendChild(fragment);
    }*/
    private _renderChunk(fromPos:any, howMany:any) {
        this.tempArray = [];
        var finalItem = fromPos + howMany;
        if (finalItem > this.totalRows)
            finalItem = this.totalRows;

        for (var i = fromPos; i < finalItem; i++) {
                this.items[i].variable = this.sanitizer.bypassSecurityTrustStyle((i * this.itemHeight) + 'px');
                this.tempArray.push(this.items[i]);
        }
    }

    private createScroller(h:any){
        var scroller = document.createElement('div');
        scroller.style.opacity = "0";
        scroller.style.position = 'absolute';
        scroller.style.top = "0";
        scroller.style.left = "0";
        scroller.style.width = '1px';
        scroller.style.height = h + 'px';
        return scroller;
    }
    private sortList(){

       /* var len = this.items.length;
        for (var i = len-1; i>=0; i--){
            for(var j = 1; j<=i; j++){
            if(this.items[j-1].value>this.items[j].value){
                var temp = this.items[j-1];
                this.items[j-1] = this.items[j];
                this.items[j] = temp;
                }
            }
        }
        */
        this.items = this.mergeSort(this.items);
        console.log( this.items);
        this.updateView(this.scrollTop);
    }

    private mergeSort(arr){
        var len = arr.length;
        if(len <2)
            return arr;
        var mid = Math.floor(len/2),
            left = arr.slice(0,mid),
            right =arr.slice(mid);
        //send left and right to the mergeSort to broke it down into pieces
        //then merge those
        return this.merge(this.mergeSort(left),this.mergeSort(right));
    }
    private merge(left, right){
        var result = [],
            lLen = left.length,
            rLen = right.length,
            l = 0,
            r = 0;
        while(l < lLen && r < rLen){
            if(left[l].value < right[r].value){
            result.push(left[l++]);
            }
            else{
            result.push(right[r++]);
            }
        }  
        //remaining part needs to be addred to the result
        return result.concat(left.slice(l)).concat(right.slice(r));
    }

 }
