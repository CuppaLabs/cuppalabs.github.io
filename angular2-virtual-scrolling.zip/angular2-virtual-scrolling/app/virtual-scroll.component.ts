import { Component, OnInit, OnChanges, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';

@Component({
  selector: 'virtual-scroll',
  templateUrl: 'app/virtual-scroll.template.html',
  styleUrls: ['app/virtual-scroll.styles.css'],
})
export class VirtualScroll implements AfterViewInit{ 
    
    @Input() datalist: any;
    @Input() config: any;

    private width:any;
    private height:any;
    private itemHeight:any;
    private items:any;
    private totalRows:any;
    private screenItemsLen:any;
    private cachedItemsLen:any;
    private lastRepaintY: any;
    private maxBuffer:any;
    private lastScrolled:any;
    private contianer:any
    private rmNodeInterval:any;
    private totalHeight: any;
    private scroller:any;

    constructor(private _elementRef : ElementRef) {   
    }

    ngOnInit() {
        console.log(this._elementRef);
        this.width = (this.config && this.config.w + 'px') || '100%';
        this.height = (this.config && this.config.h + 'px') || '100%';
        this.itemHeight = this.config.itemHeight;
        this.items = this.config.items;
        this.totalRows = this.config.totalRows || (this.config.items && this.config.items.length);
        this.screenItemsLen = Math.ceil(this.config.h / this.itemHeight);
        this.cachedItemsLen = this.screenItemsLen * 3;
        this.totalHeight = this.itemHeight * this.totalRows;
        this.scroller = this.createScroller(this.totalHeight);
        this.maxBuffer = this.screenItemsLen * this.itemHeight;
        this.lastScrolled = 0;

    }
    ngAfterViewInit() {
        console.log(this._elementRef.nativeElement.getElementsByClassName("container")[0]);
        this._renderChunk(this._elementRef.nativeElement.getElementsByClassName("container")[0], 0, this.cachedItemsLen / 2);
        this._elementRef.nativeElement.getElementsByClassName("container")[0].addEventListener('scroll', this.onScroll.bind(this));
    }

    private onScroll(e:any) {
        var scrollTop = e.target.scrollTop;
        var first = (scrollTop / this.itemHeight) - this.screenItemsLen;
        var firstTemp = ""+first;
        first = parseInt(firstTemp) < 0 ? 0 : parseInt(firstTemp);
        if (!this.lastRepaintY || Math.abs(scrollTop - this.lastRepaintY) > this.maxBuffer) {
            this._renderChunk(this._elementRef.nativeElement.getElementsByClassName("container")[0], first, this.cachedItemsLen);
            this.lastRepaintY = scrollTop;
        }
        e.preventDefault && e.preventDefault();
    }
    /*
        Create Row DOM, iterating through the data array
    */
    private createRow(i:any) {
        var item:any;
        if (typeof this.items[i] === 'string') {
            var itemText = document.createTextNode(this.items[i]);
            item = document.createElement('div');
            item.style.height = '31px';
            item.appendChild(itemText);
            } else {
            item = this.items[i];
            }
        item.classList.add('vrow');
        item.style.position = 'absolute';
        item.style.top = (i * this.itemHeight) + 'px';
        return item;
    }

    private _renderChunk(node:any, fromPos:any, howMany:any) {
        var fragment = document.createDocumentFragment();
        fragment.appendChild(this.scroller);
        var finalItem = fromPos + howMany;
        if (finalItem > this.totalRows)
            finalItem = this.totalRows;

        for (var i = fromPos; i < finalItem; i++) {
            var item;
            if (typeof this.items[i] === 'string') {
                var itemText = document.createTextNode(this.items[i]);
                item = document.createElement('div');
                //item.style.height = this.height;
                item.appendChild(itemText);
            } else {
                item = this.items[i];
            }

            item.classList.add('vrow');
            item.style.position = 'absolute';
            item.style.top = (i * this.itemHeight) + 'px';
            fragment.appendChild(item);
        }
        node.innerHTML = '';
        node.appendChild(fragment);
    }

    private createScroller(h:any){
        var scroller = document.createElement('div');
        scroller.style.opacity = "0";
        scroller.style.position = 'absolute';
        scroller.style.top = "0";
        scroller.style.left = "0";
        scroller.style.width = '1px';
        scroller.style.height = h + 'px';
        return scroller;
    }
 }
