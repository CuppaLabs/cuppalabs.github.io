import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { VirtualScroll }  from './virtual-scroll.component';
import {KeysPipe} from './keypipe'

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, VirtualScroll,KeysPipe ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
