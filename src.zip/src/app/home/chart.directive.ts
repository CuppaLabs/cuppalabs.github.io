import { Component, Directive, ElementRef } from '@angular/core';
import {heatmap} from 'heatmap/heatmap';
@Directive({
  selector: "[sm-chart]"
})
export class smChart {
  constructor(el: ElementRef) {
      console.log(el);
      heatmap(el.nativeElement);
  }
}