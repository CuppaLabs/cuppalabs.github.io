import { Component }        from '@angular/core';
import { Router,
         NavigationExtras } from '@angular/router';
import { Observable }           from 'rxjs/Observable';
import { AuthService }      from './auth.service';
import { ActivatedRoute }       from '@angular/router';

@Component({
  template: `
    <h2>LOGIN</h2>
    <p>{{message}}</p>
    <p>
      <button (click)="login()">Login</button>
      <button (click)="logout()" *ngIf="authService.isLoggedIn =='true'">Logout</button>
    </p>`
})
export class LoginComponent {
  message: string;
  clientId = "8866df478d05617ba354";
  redirectURI = "http://localhost:3000/admin";
  code: string;
  mywindow: Window;
  constructor(private route: ActivatedRoute, public authService: AuthService, public router: Router) {
    this.setMessage();
  }

  setMessage() {
    this.message = 'Logged ' + (this.authService.isLoggedIn ? 'in' : 'out');
  }

  login() {
    this.message = 'Trying to log in ...';
    window.location.href = 'https://github.com/login/oauth/authorize?client_id='+this.clientId+'&redirect_uri='+this.redirectURI;
  }
  authenticateUser(){
        this.authService.login(this.code,this.clientId).subscribe((data:any) => {
          alert("token"+data.token);
          this.setMessage();
          if (data.token) {
            sessionStorage.setItem('isLoggedIn', 'true');
            // Get the redirect URL from our auth service
            // If no redirect has been set, use the default
            let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/admin';

            // Set our navigation extras object
            // that passes on our global query params and fragment
            let navigationExtras: NavigationExtras = {
              preserveQueryParams: false,
              preserveFragment: false
            };

            // Redirect the user
            this.router.navigate([redirect],navigationExtras);
          }
        });
  }
  logout() {
    this.authService.logout();
    this.setMessage();
  }

    ngOnInit() {
    // Capture the session ID if available
    this.route
      .queryParams
      .subscribe(
      (param: any) => {
        this.code = param['code'];
       //alert(this.code);
        if(this.code){
           // window.close();
           this.authenticateUser();
        }
      });
  }
}


/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/