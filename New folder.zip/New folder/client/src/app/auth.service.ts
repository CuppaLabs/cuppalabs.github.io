import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { InterceptorService } from 'ng2-interceptors';

@Injectable()
export class AuthService {
  isLoggedIn: string = sessionStorage.getItem('isLoggedIn');
  sessionVariable: string = sessionStorage.getItem('isLoggedIn');
  if(sessionVariable){
      this.isLoggedIn = sessionStorage.getItem('isLoggedIn');
  }
  constructor(private _http: InterceptorService) {
    
  }
  // store the URL so we can redirect after logging in
  redirectUrl: string;

  login(code:any,clientId:any):any{
    
    var body = {"code" : code,"clientId" : clientId}

    return this._http.post('http://localhost:5000/auth/github',body,{})
     .map((r: Response) => { 
       
       return r.json()
      });
   // return Observable.of(true).delay(1000).do(val => this.isLoggedIn = sessionStorage.getItem('isLoggedIn'));
  }

  logout(): void {
    sessionStorage.setItem('isLoggedIn','false');
  }
}